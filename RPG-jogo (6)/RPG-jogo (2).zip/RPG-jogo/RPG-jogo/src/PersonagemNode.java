public class PersonagemNode {

    Personagem personagem;
    PersonagemNode proximo;

    PersonagemNode(Personagem personagem) {
        this.personagem = personagem;
        this.proximo = null;
    }

}
