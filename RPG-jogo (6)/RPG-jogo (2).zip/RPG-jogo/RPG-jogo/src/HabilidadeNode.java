public class HabilidadeNode{
    String nome;
    int dano;
    int manaNecessaria;
    HabilidadeNode proximo;

    HabilidadeNode(String nome, int dano, int manaNecessaria) {
        this.nome = nome;
        this.dano = dano;
        this.manaNecessaria = manaNecessaria;
        this.proximo = null;
    }
}