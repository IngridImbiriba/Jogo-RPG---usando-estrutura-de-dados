import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Jogador jogador = null;
        boolean executando = true;

        while (executando) {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1. Cadastrar Jogador");
            System.out.println("2. Login");
            System.out.println("3. Criar Personagem");
            System.out.println("4. Acessar Loja");
            System.out.println("5. Iniciar Batalha");
            System.out.println("6. Sair");
            System.out.print("Escolha uma opção: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();
            limparTela(); 

            switch (opcao) {
                case 1:
                    jogador = Jogador.cadastrar(scanner);
                    System.out.println("Jogador cadastrado com sucesso!");
                    break;
                case 2:
                    System.out.print("Digite seu nome: ");
                    String nome = scanner.nextLine();
                    System.out.print("Digite sua senha: ");
                    String senha = scanner.nextLine();
                    if (jogador != null && jogador.autenticar(nome, senha)) {
                        System.out.println("Login bem-sucedido!");
                    } else {
                        System.out.println("Credenciais inválidas ou jogador não cadastrado.");
                        jogador = null;
                    }
                    break;
                case 3:
                    if (verificaLogin(jogador)) {
                        jogador.criarPersonagem(scanner, jogador);
                    }
                    break;
                
                case 4:
                if (verificaLogin(jogador)) {
                Personagem personagemLoja = jogador.selecionarPersonagem(scanner);
                if (personagemLoja != null) {
                personagemLoja.loja();
                } else {
                System.out.println("Nenhum personagem selecionado.");
                } 
                } 
                break;
                case 5:
                    if (verificaLogin(jogador)) { // tem que colocar aqui o modo de batalhas (PvP e PvE)
                        Personagem personagemBatalha = jogador.selecionarPersonagem(scanner);
                        if (personagemBatalha != null) {
                            Batalha batalha = new Batalha();
                            batalha.adicionarParticipante(personagemBatalha);
                            System.out.println("Adicione mais personagens para batalhar? (s/n)");
                            while (scanner.nextLine().equalsIgnoreCase("s")) {
                                Personagem outro = jogador.selecionarPersonagem(scanner);
                                if (outro != null && !outro.equals(personagemBatalha)) {
                                    batalha.adicionarParticipante(outro);
                                } else {
                                    System.out.println("Personagem inválido ou já adicionado.");
                                }
                                System.out.println("Adicionar outro personagem? (s/n)");
                            }
                            batalha.iniciarBatalha();
                        }
                    }
                    break;
                case 6:
                    System.out.println("Saindo do jogo...");
                    executando = false;
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        }

        scanner.close();
    }

    private static boolean verificaLogin(Jogador jogador) {
        if (jogador == null) {
            System.out.println("Você precisa estar logado para acessar essa opção.");
            return false;
        }
        return true;
    }
    public static void limparTela() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
    private static void iniciarBatalhaPvP (Personagem personagem, Jogador jogador) {
        System.out.println("Você escolheu batalhar contra outro jogador!");
        Personagem outroPersonagem = jogador.selecionarPersonagem(new Scanner(System.in));
        if (outroPersonagem != null) {
            System.out.println("Batalha PvP iniciada!");
            batalhaTurno(personagem, outroPersonagem);
        }
    }

    private static void batalhaTurno(Personagem atacante, Personagem defensor) {
        Scanner scanner = new Scanner(System.in);
        boolean batalhando = true;

        while (batalhando) {
            System.out.println("\n=== TURNO ===");
            System.out.println("1. Atacar");
            System.out.println("2. Usar Habilidade");
            System.out.println("3. Usar Item");
            System.out.println("4. Defender");
            System.out.println("5. Fugir");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();
            limparTela(); 
            switch (opcao) {
                case 1:
                    System.out.println(atacante.getNome() + " atacou " + defensor.getNome() + "!");
                    defensor.receberDano(20); 
                    if (!defensor.estaVivo()) {
                        System.out.println(defensor.getNome() + " foi derrotado!");
                        batalhando = false;
                    }
                    break;
                case 2:
                    System.out.println(atacante.getNome() + " usou uma habilidade!");
                    defensor.receberDano(20); 
                    if (!defensor.estaVivo()) {
                        System.out.println(defensor.getNome() + " foi derrotado!");
                        batalhando = false;
                    }
                    break;
                case 3:
                    System.out.println(atacante.getNome() + " usou um item!");
                    break;
                case 4:
                    System.out.println(atacante.getNome() + " se defendeu!");
                    break;
                case 5:
                    System.out.println(atacante.getNome() + " fugiu da batalha!");
                    batalhando = false;
                    break;
                default:
                    System.out.println("Opção inválida.");
            }

            if (atacante.estaVivo() && defensor.estaVivo()) {
                System.out.println(defensor.getNome() + " responde ao ataque!");
                atacante.receberDano(10);
                if (!atacante.estaVivo()) {
                    System.out.println(atacante.getNome() + " foi derrotado!");
                    batalhando = false;
                }
            }
}
    }
}
