import java.util.Scanner;

public class Personagem {
    private static int geradorId = 1;
    private int idPersonagem;
    private String nome;
    private int nivel;
    private int vidaMaxima, vidaAtual;
    private int manaMaxima, manaAtual;
    private Jogador dono;

    // Habilidades e Itens como listas encadeadas
    private HabilidadeNode habilidades;
    private ItemNode inventario;

    // Construtor
    public Personagem(String nome, Jogador dono) {
        this.idPersonagem = geradorId++;
        this.nome = nome;
        this.dono = dono;
        this.nivel = 1;
        this.vidaMaxima = 100;
        this.vidaAtual = vidaMaxima;
        this.manaMaxima = 50;
        this.manaAtual = manaMaxima;
        this.habilidades = null;
        this.inventario = null;
    }

    // Recebe dano e reduz a vida
    public void receberDano(int valor) {
        this.vidaAtual -= valor;
        if (vidaAtual < 0) vidaAtual = 0;
    }
    public void defender() {
        System.out.println(this.getNome() + " se prepara para resistir aos danos!");
    }

    // Cura o personagem, não ultrapassando a vida máxima
    public void curar(int valor) {
        this.vidaAtual += valor;
        if (vidaAtual > vidaMaxima) vidaAtual = vidaMaxima;
    }

    // Verifica se o personagem está vivo
    public boolean estaVivo() {
        return vidaAtual > 0;
    }

    // Sobe de nível
    public void subirNivel() {
        this.nivel++;
        this.vidaMaxima += 10;
        this.manaMaxima += 5;
        this.vidaAtual = vidaMaxima;
        this.manaAtual = manaMaxima;
    }

    // Adiciona uma habilidade à lista de habilidades
    public void adicionarHabilidade(String nome, int dano, int manaNecessaria) {
        habilidades = inserirHabilidade(habilidades, nome, dano, manaNecessaria);
    }

    // Adiciona um item ao inventário
    public void adicionarItem(String nome, int quantidade) {
        inventario = inserirItem(inventario, nome, quantidade);
    }

    // Insere uma habilidade na lista de habilidades (lista encadeada)
    private HabilidadeNode inserirHabilidade(HabilidadeNode cabeca, String nome, int dano, int manaNecessaria) {
        HabilidadeNode novo = new HabilidadeNode(nome, dano, manaNecessaria);
        if (cabeca == null) {
            return novo;
        } else {
            HabilidadeNode temp = cabeca;
            while (temp.proximo != null) {
                temp = temp.proximo;
            }
            temp.proximo = novo;
            return cabeca;
        }
    }

    // Insere um item na lista de itens (lista encadeada)
    private ItemNode inserirItem(ItemNode cabeca, String nome, int quantidade) {
        ItemNode novo = new ItemNode(nome, quantidade);
        if (cabeca == null) {
            return novo;
        } else {
            ItemNode temp = cabeca;
            while (temp.proximo != null) {
                temp = temp.proximo;
            }
            temp.proximo = novo;
            return cabeca;
        }
    }

    // Exibe todas as habilidades do personagem
    public void mostrarHabilidades() {
        HabilidadeNode temp = habilidades;
        while (temp != null) {
            System.out.println("Habilidade: " + temp.nome + ", Dano: " + temp.dano + ", Mana Necessária: " + temp.manaNecessaria);
            temp = temp.proximo;
        }
    }

    // Exibe todos os itens no inventário
    public void mostrarInventario() {
        ItemNode temp = inventario;
        while (temp != null) {
            System.out.println("Item: " + temp.nome + ", Quantidade: " + temp.quantidade);
            temp = temp.proximo;
        }
    }

    public void loja() {
        // Exibe as opções de itens e habilidades disponíveis para compra
        System.out.println("Bem-vindo à loja! Seu saldo de moedas: " + dono.getSaldoMoedas() + " moedas.");
        System.out.println("Escolha o que deseja comprar:");

        // Exemplo de habilidades e itens que podem ser comprados
        System.out.println("1. Habilidade de Ataque (Custo: 50 moedas)");
        System.out.println("2. Habilidade de Defesa (Custo: 40 moedas)");
        System.out.println("3. Poção de Vida (Custo: 30 moedas)");
        System.out.println("4. Espada (Custo: 60 moedas)");

        // Recebe a escolha do jogador
        Scanner scanner = new Scanner(System.in);
        int opcao = scanner.nextInt();

        if (opcao == 1 && dono.getSaldoMoedas() >= 50) {
            adicionarHabilidade("Ataque", 30, 10);
            dono.removerMoedas(50);
            System.out.println("Você comprou a habilidade Ataque!");
        } else if (opcao == 2 && dono.getSaldoMoedas() >= 40) {
            adicionarHabilidade("Defesa", 10, 5);
            dono.removerMoedas(40);
            System.out.println("Você comprou a habilidade Defesa!");
        } else if (opcao == 3 && dono.getSaldoMoedas() >= 30) {
            adicionarItem("Poção de Vida", 1);
            dono.removerMoedas(30);
            System.out.println("Você comprou a Poção de Vida!");
        } else if (opcao == 4 && dono.getSaldoMoedas() >= 60) {
            adicionarItem("Espada", 1);
            dono.removerMoedas(60);
            System.out.println("Você comprou a Espada!");
        } else {
            System.out.println("Saldo insuficiente ou opção inválida.");
        }
    }

    // Getters
    public String getNome() {
        return nome;
    }

    public int getNivel() {
        return nivel;
    }

    public int getVidaAtual() {
        return vidaAtual;
    }

    public int getManaAtual() {
        return manaAtual;
    }

    public int getIdPersonagem() {
        return idPersonagem;
    }

    public Jogador getDono() {
        return dono;
    }
    
    public int getVidaMaxima() {
        return vidaMaxima;
    }
    
    public boolean temHabilidade() {
        return habilidades!= null;
    }
    public boolean temItem() {
        return inventario!= null;
    }
}