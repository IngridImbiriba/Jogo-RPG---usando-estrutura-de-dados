import java.util.Scanner;

public class Batalha {
    private int idBatalha;
    private int turnoAtual;
    private boolean batalhaEmAndamento;

    private NoFila filaTurnos;
    private NoPilha pilhaRanking;

    private static int geradorId = 1;

    private Scanner scanner;

    public Batalha() {
        this.idBatalha = geradorId++;
        this.turnoAtual = 1;
        this.batalhaEmAndamento = false;
        this.filaTurnos = null;
        this.pilhaRanking = null;
        this.scanner = new Scanner(System.in);
    }

    private class NoFila {
        Personagem personagem;
        NoFila proximo;

        NoFila(Personagem personagem) {
            this.personagem = personagem;
        }
    }

    private class NoPilha {
        Personagem personagem;
        NoPilha proximo;

        NoPilha(Personagem personagem) {
            this.personagem = personagem;
        }
    }

    public void adicionarParticipante(Personagem personagem) {
        if (personagem != null && personagem.estaVivo()) {
            NoFila novo = new NoFila(personagem);
            if (filaTurnos == null) {
                filaTurnos = novo;
                novo.proximo = novo;
            } else {
                novo.proximo = filaTurnos.proximo;
                filaTurnos.proximo = novo;
                filaTurnos = novo;
            }
        }
    }

    public void iniciarBatalha() {
        if (filaTurnos == null) {
            System.out.println("Nenhum personagem para iniciar a batalha.");
            return;
        }
        batalhaEmAndamento = true;
        System.out.println("Batalha " + idBatalha + " iniciada!");
        while (batalhaEmAndamento) {
            executarTurno();
            verificarVencedor();
        }
        exibirRankingFinal();
    }

    private void executarTurno() {
        if (!batalhaEmAndamento || filaTurnos == null) return;

        NoFila atual = filaTurnos.proximo;
        Personagem personagem = atual.personagem;

        System.out.println("\n--- Turno " + turnoAtual + " ---");
        System.out.println("Vez de: " + personagem.getNome() + " | Vida: " + personagem.getVidaAtual() + "/" + personagem.getVidaMaxima());
        System.out.println("Saldo de moedas: " + personagem.getDono().getSaldoMoedas());

        System.out.println("Escolha sua ação:");
        System.out.println("1 - Atacar");
        System.out.println("2 - Defender");
        System.out.println("3 - Usar habilidade");
        System.out.println("4 - Usar item");
        System.out.println("5 - Fugir");

        int escolha = scanner.nextInt();
        scanner.nextLine();

        switch (escolha) {
            case 1:
                atacar(personagem);
                break;
            case 2:
                defender(personagem);
                break;
            case 3:
                usarHabilidade(personagem);
                break;
            case 4:
                usarItem(personagem);
                break;
            case 5:
                fugir(personagem);
                break;
            default:
                System.out.println("Ação inválida! Perdeu o turno.");
        }

        if (!personagem.estaVivo()) {
            empilharRanking(personagem);
            removerDaFila(atual);
        } else {
            filaTurnos = atual;
        }

        turnoAtual++;
    }

    private void atacar(Personagem atacante) {
        Personagem alvo = escolherAlvo(atacante);
        if (alvo != null) {
            alvo.receberDano(10);
            System.out.println(atacante.getNome() + " atacou " + alvo.getNome() + " causando 10 de dano!");
            if (!alvo.estaVivo()) {
                System.out.println(alvo.getNome() + " foi derrotado!");
                empilharRanking(alvo);
                removerDaFila(filaTurnos);
            }
        } else {
            System.out.println("Nenhum alvo disponível.");
        }
    }

    private void defender(Personagem personagem) {
        personagem.curar(5);
        System.out.println(personagem.getNome() + " defendeu e se curou em 5 pontos!");
    }

    private void usarHabilidade(Personagem personagem) {
        if (personagem.temHabilidade()) {
            Personagem alvo = escolherAlvo(personagem);
            if (alvo != null) {
                alvo.receberDano(20);
                System.out.println(personagem.getNome() + " usou uma habilidade e causou 20 de dano em " + alvo.getNome() + "!");
                if (!alvo.estaVivo()) {
                    System.out.println(alvo.getNome() + " foi derrotado!");
                    empilharRanking(alvo);
                    removerDaFila(filaTurnos);
                }
            }
        } else {
            System.out.println("Nenhuma habilidade disponível no inventário.");
        }
    }

    private void usarItem(Personagem personagem) {
        if (personagem.temItem()) {
            Personagem alvo = escolherAlvo(personagem);
            if (alvo != null) {
                // Suponha que o item cause 10 de cura ou ataque (exemplo de uso)
                alvo.receberDano(10);
                System.out.println(personagem.getNome() + " usou um item e causou 10 de dano em " + alvo.getNome() + "!");
                if (!alvo.estaVivo()) {
                    System.out.println(alvo.getNome() + " foi derrotado!");
                    empilharRanking(alvo);
                    removerDaFila(filaTurnos);;
                }
            }
        } else {
            System.out.println("Nenhum item disponível no inventário.");
        }
    }

    private void fugir(Personagem personagem) {
        System.out.println(personagem.getNome() + " fugiu da batalha!");
        // Perde moedas e a batalha termina
        personagem.getDono().removerMoedas(20);
        System.out.println(personagem.getDono().getNome() + " perdeu 20 moedas por fugir da batalha.");
        batalhaEmAndamento = false;
    }

    private Personagem escolherAlvo(Personagem atacante) {
        NoFila atual = filaTurnos.proximo;
        Personagem primeiroAlvo = null;

        do {
            if (!atual.personagem.equals(atacante) && atual.personagem.estaVivo()) {
                return atual.personagem;
            }
            atual = atual.proximo;
        } while (atual != filaTurnos.proximo);

        return primeiroAlvo;
    }

    private void empilharRanking(Personagem derrotado) {
        NoPilha novo = new NoPilha(derrotado);
        novo.proximo = pilhaRanking;
        pilhaRanking = novo;
    }

    private void removerDaFila(NoFila derrotado) {
        if (filaTurnos == null) return;

        NoFila atual = filaTurnos;
        do {
            if (atual.proximo == derrotado) {
                if (derrotado == filaTurnos) {
                    if (filaTurnos == filaTurnos.proximo) {
                        filaTurnos = null;
                    } else {
                        atual.proximo = derrotado.proximo;
                        filaTurnos = atual;
                    }
                } else {
                    atual.proximo = derrotado.proximo;
                }
                return;
            }
            atual = atual.proximo;
        } while (atual != filaTurnos);
    }

    private void verificarVencedor() {
        if (filaTurnos == null || filaTurnos.proximo == filaTurnos) {
            batalhaEmAndamento = false;
            if (filaTurnos != null) {
                empilharRanking(filaTurnos.personagem);
                System.out.println("\n\nVencedor: " + filaTurnos.personagem.getNome());
                filaTurnos.personagem.getDono().adicionarMoedas(50);
                filaTurnos.personagem.subirNivel(); // O vencedor sobe de nível
                System.out.println(filaTurnos.personagem.getDono().getNome() + " recebeu 50 moedas e subiu de nível!");
            }
        }
    }

    private void exibirRankingFinal() {
        System.out.println("\n=== RANKING FINAL ===");
        NoPilha atual = pilhaRanking;
        int posicao = 1;
        while (atual != null) {
            System.out.println(posicao + "º - " + atual.personagem.getNome());
            atual = atual.proximo;
            posicao++;
        }
    }
}